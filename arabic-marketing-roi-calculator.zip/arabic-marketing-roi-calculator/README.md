# Arabic Marketing ROI Calculator

Lightweight open-source Arabic RTL marketing calculator and web utility. No dependencies, build step, accounts, or external network requests.

حاسبة عربية تفاعلية لمؤشرات ROI, ROAS, CAC, CPL, CPC, CPM, CTR والربح وهامش الربح والتحويل وإيرادات التعادل. تدعم أربع عملات للعرض وتصدير CSV. البيانات الأولية مثال افتراضي، وليست نتائج حقيقية.

## Run locally / التشغيل
Open `index.html` in a modern browser. No server required.

## GitHub Pages
1. Create a public repository named `arabic-marketing-roi-calculator`.
2. Upload the extracted project files to the repository root, not the ZIP archive.
3. In Settings → Pages → Build and deployment, select Deploy from a branch, `main` and `/ (root)`, then Save.
4. Open the URL provided by GitHub Pages.

## Metrics and assumptions
ROI = (attributed revenue - direct costs - total marketing costs) / total marketing costs × 100. ROAS = attributed revenue / ad spend. CAC = total marketing costs / new customers. CPL, CPC and CPM use ad spend only. Lead conversion assumes new customers and leads are from the same cohort. Break-even revenue holds entered costs fixed; it is not a variable-cost forecast. Zero denominators are undefined. Currency selection does not convert amounts. No data is transmitted or persisted.

## Tests
Run `node test.js` (Node.js required only for tests).

## License
MIT.
